# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:setup command.
# > rake db:setup
	# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:setup command.
# > rake db:setup
	
	Item.create(:content => "Mythe Barn",:description => "Mythe Barn is found near the market town of Atherstone. Its convenient location close to the cities of Birmingham, Leicester and Coventry, combined with its expert design; ensure it is a most beautiful barn wedding venue in the Midlands.", :img_url => 'Mythebarne.jpg', :price => 1000, :date_published => "2014/12/31")
    
	Item.create(:content => "Brooksby Hall",:description => "Set on an expansive estate that covers 850 acres, Brooksby Hall in Leicestershire is a grand,16th Century manor house wedding venue nestled in the rolling, verdant countryside." ,:img_url => 'Brooksbyhall.jpg', :price => 800, :date_published => "2000/12/31")
	
	Item.create(:content => "Crockwell Farm",:description => "Crockwell Farm is an intimate and romantic barn wedding venue nestled in the rolling Northamptonshire countryside." ,:img_url => 'Crockwell.jpg', :price => 650, :date_published => "2000/12/31")
	
	Item.create(:content => "Plaza Hotel",:description => "Offering a variety of sophisticated spaces of varying shapes and sizes, located in London plaza hotel is the perfect NYC wedding venue. The hotel combines its illustrious history, engaging architecture, and state of the art AV equipment to make each wedding reception as effortless as possible." , 
	:img_url => 'PlazaHotel.jpg', :price => 1000, :date_published => "2016/02/14")

	Item.create(:content => "Viladomat Gardens",:description => "Without a doubt England’s most iconic garden, a wedding at Viladomat Gardens is guaranteed to knock your guests’ socks off. The iconic Orangery is not only Grade I listed but open plan, and with high ceilings, your wedding breakfast will be filled with the crispy light of spring. Or choose The Princess of Wales Conservatory for a shamelessly regal evening reception." , 
	:img_url => 'Viladomat.jpg', :price => 1000, :date_published => "2016/02/14")
   
	Item.create(:content => "Hampshire Gardens",:description => "The Hampshire gardens is the wow factor you're after, this iconic London landmark, Ceremonies take place on level 39 with sweeping views of St Pauls Cathedral. You and your party can then head up to the glass dome - 180 metres above ground level - for champagne and canapés." , 
	:img_url => 'Hampshire.jpg', :price => 1000, :date_published => "2016/02/14")
   
	Item.create(:content => "Calabria Hall",:description => "Calabria Hall is a wonderful destination for your romantic wedding event. Located in West London, this family-owned, indoor reception venue has an upscale atmosphere that serves as a polished backdrop for your wedding. The Calabria Hall was established in 2003 and focuses on using its stunning space to make your vision a reality." , 
	:img_url => 'Calabria.jpg', :price => 1000, :date_published => "2016/02/14")
   
	Item.create(:content => "Rockingham Hall",:description => "The marquee interior has been designed with flexibility in mind. The neutral ivory lining lends itself perfectly to any colour scheme or wedding design, whether you’re looking to create the ultimate in traditional celebrations or would prefer a contemporary look for your special day." , 
	:img_url => 'Rockingham.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Taj Hall",:description => "This modern day hall provides an excellent feel and unique atmosphere.The stunning structure gives a passioate and intimate feel to the occasion which will be ideal for your special ." , 
	:img_url => 'TajHall.jpg', :price => 1000, :date_published => "2016/02/14")

   Item.create(:content => "Burgess Garden",:description => "Perfect location for a summer time wedding. Indulge in natures beauty while enjoying your special day, with the love of your life, friends and Family. This venue is very popular and during the summer months is highly booked." , 
	:img_url => 'Burgess.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Guang Hall",:description => "Guang Hall is a wonderful asian venue which brings out all the dynamic colours. The beautiful scenario adds to the special occasion. The hall is more or less an open one which makes it very huge allwing loads of guests to join you." , 
	:img_url => 'Guang.jpg', :price => 1000, :date_published => "2016/02/14")

   Item.create(:content => "Ascorts hall",:description => "Ascorts Hall is one of the most popular wedding venues in north England. The hall is within a rejuvenated barn which adds to a unique feel. This iconic barn in North England is a perfect fit for a cultured wedding. " , 
	:img_url => 'Ascort.jpg', :price => 1000, :date_published => "2016/02/14")

   Item.create(:content => "Anvil Hall",:description => "A unique and beautiful building, Anvil Hall has provided the backdrop for many thousands of Gretna weddings, and has become one of North Englands most popular wedding venues since it opened in 2006. " , 
	:img_url => 'Anvil.jpg', :price => 1000, :date_published => "2016/02/14")

   Item.create(:content => "Auchen Castle",:description => "Jewel of the Scottish Borders, Auchen Castle is one of Scotland's most sought after wedding destinations. Located a short drive from Gretna Green in the heart of Robert Burns country, a wedding at this historic castle hotel is an unforgettable experience." , 
	:img_url => 'Auchen.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Ladywood",:description => "The impressive Leicestershire venue is the ideal setting for your fairy-tale wedding. Every wedding held here can make full, exclusive use of the house and the tranquil grounds for up to three days, allowing you to enjoy a wonderful wedding weekend." , 
	:img_url => 'lady.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Shearsby Hall",:description => "In its charming countryside location, Shearsby Bath is the perfect venue for your special wedding day. The Leicestershire venue offers all you could need for a wonderful wedding with the flexibility to make your day suit you perfectly." , 
	:img_url => 'Shearsby.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Millenium Hall",:description => "The purpose built Conference Suite in our inn can cater up to 160 reception guests and is host to its own lounge and bar. The function suites are modern and feature high ceilings and a luxurious marble entrance floor." , 
	:img_url => 'Millenium.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Centenary Hall",:description => "A truly impressive 30 bedroom building that is surrounded by 10 acres of private grounds, Rothley Court is an ideal wedding venue for up to 85 guests that also features its own chapel, babbling brook and rose walk." , 
	:img_url => 'Centenary Hall.jpg', :price => 1000, :date_published => "2016/02/14")
   
    Item.create(:content => "Centenary Hall",:description => "A truly impressive 30 bedroom building that is surrounded by 10 acres of private grounds, Rothley Court is an ideal wedding venue for up to 85 guests that also features its own chapel, babbling brook and rose walk." , 
	:img_url => 'Centenary Hall.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Keith Weller Hall",:description => "welcome you to our captivating and elegant property set in a Victorian conservation area in the heart of the city center. We are licensed for civil ceremonies & partnerships and can arrange anything from small intimate ceremonies or those for up to 150 guests." ,
	:img_url => 'Weller.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Harrison Gardens",:description => "Harrison Gardens has incredible panoramic views of the racecourse located around it, also has a beautiful terrace, where your Guests can enjoy drinks overlooking the winning post." ,
	:img_url => 'Harrison.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Summer Hall",:description => "The happy couple can spend their first night of wedded bliss in a honeymoon suite unlike any other. The luxurious treehouse boasts stylish design and state-of-the-art entertainment and music systems." ,
	:img_url => 'Summer.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Marriot Hotel",:description => "Here to ensure that your wedding day will be the most joyous day of your life. We’ll start by providing a wedding planner dedicated to minimizing your stress and maximizing the enjoyment of the day for you and your guests." ,
	:img_url => 'Marriot.jpg', :price => 1000, :date_published => "2016/02/14")
   
	Item.create(:content => "Michellin Hall",:description => "The versatile, stylish banqueting hall offers space for up to 200 guests for your evening celebrations and live entertainment, as well as a charming location for your romantic ceremony." ,
	:img_url => 'Michellin.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Empire State Hall",:description => "Set within the grounds, the Empire State hall is ideal for grand celebrations with up to 400 guests." ,
	:img_url => 'Empire.jpg', :price => 1000, :date_published => "2016/02/14")
   
   Item.create(:content => "Platinum Hall",:description => "The Platinum Hall is the perfect venue for one of the most important days of your life – your wedding. The impressive, elegant spaces are ideal for your ceremony, wedding breakfast and evening reception. The venue is also ideal for Asian weddings and engagements." ,
	:img_url => 'Platinum.jpg', :price => 1000, :date_published => "2016/02/14")
   
   
   
Product.delete_all
Product.create! id: 1, name: "Bug Table & 12 Chairs & Cutlery", price: 19.99, active: true
Product.create! id: 2, name: "Flowers Per Table", price: 12.99, active: true
Product.create! id: 3, name: "Decoration Set", price: 149.99, active: true
Product.create! id: 4, name: "Singer", price: 499.99, active: true

OrderStatus.delete_all
OrderStatus.create! id: 1, name: "In Progress"
OrderStatus.create! id: 2, name: "Placed"
OrderStatus.create! id: 3, name: "Shipped"
OrderStatus.create! id: 4, name: "Cancelled"