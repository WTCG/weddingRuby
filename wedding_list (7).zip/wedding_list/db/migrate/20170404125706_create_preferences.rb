class CreatePreferences < ActiveRecord::Migration
  def change
    create_table :preferences do |t|
      t.boolean :is_preferred
      t.references :interest, index: true, foreign_key: true
      t.timestamp :date

      t.timestamps null: false
    end
  end
end
