class AddDatePublishedToItems < ActiveRecord::Migration
  def change
    add_column :items, :date_published, :date
  end
end
