require 'test_helper'

class HomepageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
