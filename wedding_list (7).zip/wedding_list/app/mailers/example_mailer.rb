class ExampleMailer < ApplicationMailer

	default to: "Reviewer"
	
	def sample_email(user)
    @user = user
    mail(from: @user.email, subject: 'Contact Us Client')
	
  end

end
