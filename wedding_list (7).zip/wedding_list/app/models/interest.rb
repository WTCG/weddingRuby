class Interest < ActiveRecord::Base
end
