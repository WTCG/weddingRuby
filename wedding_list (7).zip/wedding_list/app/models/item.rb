class Item < ActiveRecord::Base


# a simple search which returns all objects whose title 
	# is the same as the value of a search_string
	def self.search(search)
		where("content LIKE ?", "%#{search}%")
	end

	# a fuzzy search which returns all objects whose title 
	# contains some part of the value of a search_string

##def self.simple_search(search_string)
	#	self.find(:all, :conditions => ["content = ?", search_string])
#end
 #def self.search(search)
  ##where("content LIKE ? OR description LIKE ? OR price LIKE ?", "%#{search}%", "%#{search}%", "%#{search}%", "%#{search}%") 
#end
	
	

end
