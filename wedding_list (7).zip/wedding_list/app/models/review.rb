class Review < ActiveRecord::Base
end
