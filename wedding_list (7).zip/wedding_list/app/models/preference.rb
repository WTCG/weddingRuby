class Preference < ActiveRecord::Base
  belongs_to :interest
end
