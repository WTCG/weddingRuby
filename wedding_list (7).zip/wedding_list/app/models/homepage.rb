class Homepage < ActiveRecord::Base
end
